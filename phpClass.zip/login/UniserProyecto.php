<?php
    if(isset($_POST['codigo']) && isset($_POST['codigoProfesor'])){
        // Include the necessary files
        require_once "conn.php";
        require_once "validate.php";
        // Call validate, pass form data as parameter and store the returned value
        $codigo = validate($_POST['codigo']);
        $id = validate($_POST['codigoProfesor']);
        // Create the SQL query string
        $sql = "insert into participar values ('$codigo','$id','1')";
        // Execute the query
        $result = $conn->query($sql)or die ("ERROR en la consulta $sql".mysqli_error($conn));
    }
?>