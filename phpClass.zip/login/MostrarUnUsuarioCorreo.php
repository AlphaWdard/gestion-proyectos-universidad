<?php
 if($_SERVER['REQUEST_METHOD']=='GET'){
    // Include the necessary files
    $correo=$_GET['correo'];
    require_once "conn.php";
    // Create the SQL query string
    $sql = "select * FROM users WHERE email='$correo'";
    $res = $conn->query($sql);
    if($conn->affected_rows>0){
        while($row=$res->fetch_assoc()){
            echo $row["email"];
        }
        
    }else{
        echo "No existe el Grupos Investigacion";
    }

    }
?>