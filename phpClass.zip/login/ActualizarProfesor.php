<?php

require_once "conn.php";

$id = $_REQUEST['id'];
$nombre = $_REQUEST['nombre'];
$titulo = $_REQUEST['titulo'];

$sql = "update profesor set nombre = '$nombre', Titulo = '$titulo' where id='$id'";
$res = $conn->query($sql) or die ("Error al insertar datos".mysqli_error($conn));  


?>