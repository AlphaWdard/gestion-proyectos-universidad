<?php
 if($_SERVER['REQUEST_METHOD']=='GET'){
    // Include the necessary files
    require_once "conn.php";
    // Create the SQL query string
    $sql = "select * from grupoinvestigacion";
    $res = $conn->query($sql);
    if($conn->affected_rows>0){
        $arreglo = array($conn->affected_rows);
        $j = 0;
        while($row=$res->fetch_assoc()){
            $arreglo[$j] = $row;
            $j ++;
        }
        echo json_encode($arreglo);
    }else{
        echo "No existe el Grupos Investigacion";
    }

    }
?>