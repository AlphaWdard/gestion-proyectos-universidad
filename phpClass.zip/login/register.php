<?php

    // Include the necessary files
    require_once "conn.php";
    require_once "validate.php";
    // Call validate, pass form data as parameter and store the returned value
    $email = validate($_POST['email']);
    $password = validate($_POST['password']);
    $palabra = validate($_POST['palabra']);
    $nombre = validate($_POST['nombre']);
    $id = validate($_POST['id']);
    $titulo = validate($_POST['titulo']);
    // Create the SQL query string. We'll use md5() function for data security. It calculates and returns the MD5 hash of a string
    $sql = "insert into users values('$id','$email', '" . md5($password) . "','$palabra')";
    // Execute the query. Print "success" on a successful execution, otherwise "failure".
    $conn->query($sql);
    if($conn->affected_rows>0){
        echo "naiz";
    }
    
    $sql = "insert into profesor values ('$id','$nombre','$titulo')";

    $conn->query($sql);
    
    if($conn->affected_rows>0){
        echo "naiz";
    }
?>