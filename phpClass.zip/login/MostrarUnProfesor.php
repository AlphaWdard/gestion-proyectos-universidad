<?php
 if($_SERVER['REQUEST_METHOD']=='GET'){
    // Include the necessary files
    $codigo=$_GET['id'];
    require_once "conn.php";
    // Create the SQL query string
    $sql = "select * FROM profesor WHERE id='$codigo'";
    $res = $conn->query($sql);
    if($conn->affected_rows>0){
        while($row=$res->fetch_assoc()){
            $arreglo = $row;
        }
        echo json_encode($arreglo);
    }else{
        echo "No existe el Grupos Investigacion";
    }

    }
?>